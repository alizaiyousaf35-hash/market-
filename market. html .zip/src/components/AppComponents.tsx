import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, Download, ChevronRight, ArrowLeft, Search, MoreVertical, Share2, Check, Loader2 } from 'lucide-react';
import { AppData } from '../data';

const InstallButton = ({ className, label = "Install" }: { className?: string, label?: string }) => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'installed'>('idle');

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (status === 'idle') {
      setStatus('loading');
      setTimeout(() => setStatus('installed'), 2000);
    }
  };

  return (
    <motion.button 
      onClick={handleClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      disabled={status !== 'idle'}
      className={`${className} ${
        status === 'installed' 
          ? 'bg-green-100 text-green-700 shadow-none' 
          : 'bg-white text-black hover:bg-gray-100 shadow-lg'
      } transition-all duration-300 flex items-center justify-center gap-2`}
    >
      {status === 'loading' && <Loader2 className="w-5 h-5 animate-spin" />}
      {status === 'installed' && <Check className="w-5 h-5" />}
      {status === 'idle' ? label : status === 'loading' ? 'Installing...' : 'Open'}
    </motion.button>
  );
};

interface AppCardProps {
  app: AppData;
  onClick: (app: AppData) => void;
  variant?: 'compact' | 'featured' | 'standard' | 'chart';
  rank?: number;
}

export const AppCard = ({ app, onClick, variant = 'standard', rank }: AppCardProps) => {
  if (variant === 'featured') {
    return (
      <motion.div 
        layoutId={`container-${app.id}`}
        onClick={() => onClick(app)}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
        className="relative overflow-hidden rounded-[32px] cursor-pointer group h-[450px] w-full shadow-xl shadow-indigo-900/10 bg-white"
      >
        <motion.img 
          layoutId={`image-${app.id}`}
          src={app.screenshots[0]} 
          alt={app.title} 
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        
        <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
          <motion.div layoutId={`icon-${app.id}`} className="w-20 h-20 rounded-2xl overflow-hidden mb-5 shadow-2xl border-2 border-white/10">
            <img src={app.icon} alt="" className="w-full h-full object-cover" />
          </motion.div>
          
          <motion.h3 layoutId={`title-${app.id}`} className="text-4xl font-bold mb-3 tracking-tight">{app.title}</motion.h3>
          <p className="text-gray-200 mb-6 line-clamp-2 max-w-xl text-lg leading-relaxed opacity-90">{app.description}</p>
          
          <div className="flex items-center gap-4">
            <InstallButton className="px-8 py-3 rounded-full font-bold min-w-[140px]" />
            <span className="text-base font-medium opacity-80 flex items-center gap-1">
              {app.rating} <Star className="w-4 h-4 fill-current" />
            </span>
          </div>
        </div>
      </motion.div>
    );
  }

  if (variant === 'chart') {
    return (
      <motion.div 
        layoutId={`container-${app.id}`}
        onClick={() => onClick(app)}
        whileHover={{ backgroundColor: 'rgba(0,0,0,0.02)' }}
        whileTap={{ scale: 0.98 }}
        className="flex items-center gap-4 p-3 rounded-2xl cursor-pointer group transition-colors"
      >
        <span className="text-lg font-bold text-gray-400 w-6">{rank}</span>
        <motion.div layoutId={`icon-${app.id}`} className="w-14 h-14 rounded-xl overflow-hidden shadow-sm shrink-0 bg-gray-100">
          <img src={app.icon} alt={app.title} className="w-full h-full object-cover" />
        </motion.div>
        
        <div className="flex-1 min-w-0">
          <motion.h3 layoutId={`title-${app.id}`} className="font-semibold text-gray-900 truncate text-base">{app.title}</motion.h3>
          <p className="text-sm text-gray-500 truncate">{app.category} • {app.rating} ★</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      layoutId={`container-${app.id}`}
      onClick={() => onClick(app)}
      whileHover={{ y: -4, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" }}
      whileTap={{ scale: 0.98 }}
      className="flex flex-col p-4 rounded-3xl bg-white border border-gray-100 cursor-pointer group h-full transition-all shadow-sm hover:border-transparent"
    >
      <motion.div layoutId={`icon-${app.id}`} className="w-full aspect-square rounded-2xl overflow-hidden shadow-sm mb-4 bg-gray-50">
        <img src={app.icon} alt={app.title} className="w-full h-full object-cover" />
      </motion.div>
      
      <div className="flex-1 flex flex-col">
        <motion.h3 layoutId={`title-${app.id}`} className="font-bold text-gray-900 truncate text-lg mb-1">{app.title}</motion.h3>
        <p className="text-sm text-gray-500 mb-4 line-clamp-2 flex-1">{app.description}</p>
        <div className="flex items-center justify-between mt-auto">
          <span className="text-xs font-medium text-gray-400">{app.rating} ★</span>
          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md">GET</span>
        </div>
      </div>
    </motion.div>
  );
};

export const AppDetailView = ({ app, onClose }: { app: AppData; onClose: () => void }) => {
  return (
    <>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[90]"
      />
      <motion.div 
        layoutId={`container-${app.id}`}
        className="fixed inset-x-0 bottom-0 top-20 md:inset-20 md:top-10 z-[100] bg-white overflow-hidden rounded-t-[32px] md:rounded-[32px] shadow-2xl flex flex-col"
      >
        {/* Header Actions */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start z-20 pointer-events-none">
          <button onClick={onClose} className="p-2 bg-black/20 backdrop-blur-md hover:bg-black/30 rounded-full text-white pointer-events-auto transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex gap-2 pointer-events-auto">
            <button className="p-2 bg-black/20 backdrop-blur-md hover:bg-black/30 rounded-full text-white transition-colors">
              <Search className="w-6 h-6" />
            </button>
            <button className="p-2 bg-black/20 backdrop-blur-md hover:bg-black/30 rounded-full text-white transition-colors">
              <MoreVertical className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Hero Image Background */}
        <div className="relative h-72 shrink-0">
          <motion.img 
            layoutId={`image-${app.id}`}
            src={app.screenshots[0]} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-black/30" />
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto -mt-12 relative z-10 px-6 md:px-10 pb-10">
          <div className="flex gap-6 items-end mb-6">
            <motion.div layoutId={`icon-${app.id}`} className="w-28 h-28 rounded-[24px] overflow-hidden shadow-2xl border-4 border-white bg-white shrink-0">
              <img src={app.icon} alt="" className="w-full h-full object-cover" />
            </motion.div>
            <div className="pb-2 flex-1">
              <motion.h1 layoutId={`title-${app.id}`} className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">{app.title}</motion.h1>
              <p className="text-indigo-600 font-medium text-lg">{app.developer}</p>
            </div>
          </div>

          {/* Stats Row */}
          <div className="flex items-center justify-between py-6 border-y border-gray-100 mb-8">
            <div className="text-center px-4">
              <div className="flex items-center gap-1 justify-center font-bold text-xl text-gray-900">
                {app.rating} <Star className="w-4 h-4 fill-current text-yellow-500" />
              </div>
              <div className="text-xs text-gray-500 mt-1 font-medium">12K reviews</div>
            </div>
            <div className="w-px h-10 bg-gray-200" />
            <div className="text-center px-4">
              <div className="font-bold text-xl text-gray-900">{app.downloads}</div>
              <div className="text-xs text-gray-500 mt-1 font-medium">Downloads</div>
            </div>
            <div className="w-px h-10 bg-gray-200" />
            <div className="text-center px-4">
              <div className="font-bold text-xl text-gray-900">3+</div>
              <div className="text-xs text-gray-500 mt-1 font-medium">Rated for 3+</div>
            </div>
          </div>

          <div className="grid md:grid-cols-[2fr,1fr] gap-10">
            <div>
              {/* Screenshots Carousel */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-4">Preview</h2>
                <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-6 px-6 md:mx-0 md:px-0">
                  {app.screenshots.map((shot, i) => (
                    <img 
                      key={i} 
                      src={shot} 
                      alt="Screenshot" 
                      className="h-64 w-auto rounded-2xl shadow-md object-cover hover:scale-[1.02] transition-transform duration-300"
                    />
                  ))}
                </div>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-3 flex items-center gap-2">
                  About this app
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </h2>
                <p className="text-gray-600 leading-relaxed whitespace-pre-line text-lg">
                  {app.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mt-6">
                  {app.tags.map(tag => (
                    <span key={tag} className="px-4 py-1.5 bg-gray-100 text-gray-700 rounded-full text-sm font-medium border border-gray-200">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Sticky Install Card (Desktop) */}
            <div className="hidden md:block">
              <div className="sticky top-6 bg-gray-50 p-6 rounded-3xl border border-gray-100">
                <h3 className="font-bold text-lg mb-4">Ready to play?</h3>
                <InstallButton 
                  className="w-full py-4 rounded-full font-bold text-lg !bg-black !text-white hover:!bg-gray-900" 
                  label="Install on device"
                />
                <p className="text-xs text-center text-gray-400 mt-4">
                  Contains ads • In-app purchases
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Sticky Footer */}
        <div className="md:hidden sticky bottom-0 p-4 bg-white border-t border-gray-100 pb-8">
           <InstallButton 
              className="w-full py-4 rounded-full font-bold text-lg !bg-black !text-white hover:!bg-gray-900" 
              label="Install"
            />
        </div>
      </motion.div>
    </>
  );
};

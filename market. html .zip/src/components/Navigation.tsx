import React from 'react';
import { motion } from 'motion/react';
import { Search, Bell, Menu, User, Gamepad2, Smartphone, Joystick, Download } from 'lucide-react';

export const TopBar = ({ onSearch }: { onSearch: (query: string) => void }) => {
  return (
    <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center gap-4">
        <button className="p-2 hover:bg-gray-100 rounded-full transition-colors md:hidden">
          <Menu className="w-6 h-6 text-gray-700" />
        </button>
        
        <div className="flex-1 flex items-center bg-gray-100 hover:bg-gray-200 transition-colors rounded-full px-4 py-3 max-w-2xl mx-auto md:mx-0 focus-within:bg-white focus-within:shadow-md focus-within:ring-2 focus-within:ring-indigo-100">
          <Search className="w-5 h-5 text-gray-500 mr-3" />
          <input 
            type="text" 
            placeholder="Search apps, games, and more..." 
            className="bg-transparent border-none outline-none w-full text-gray-800 placeholder-gray-500"
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>

        <div className="hidden md:flex items-center gap-2 ml-auto">
          <button className="p-3 hover:bg-gray-100 rounded-full transition-colors relative">
            <Bell className="w-6 h-6 text-gray-700" />
            <span className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
          </button>
          <button className="p-1 hover:bg-gray-100 rounded-full transition-colors">
            <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-semibold border border-indigo-200">
              <User className="w-6 h-6" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

const NAV_ITEMS = [
  { id: 'games', label: 'Games', icon: Gamepad2 },
  { id: 'apps', label: 'Apps', icon: Smartphone },
  { id: 'arcade', label: 'Arcade', icon: Joystick },
  { id: 'updates', label: 'Updates', icon: Download },
];

export const NavigationRail = ({ activeTab, onTabChange }: { activeTab: string, onTabChange: (id: string) => void }) => {
  return (
    <div className="hidden md:flex flex-col w-24 h-[calc(100vh-73px)] sticky top-[73px] border-r border-gray-100 bg-white items-center py-8 gap-8 shrink-0">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className="flex flex-col items-center gap-2 w-full relative group"
          >
            <div className={`w-14 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
              isActive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-gray-500 group-hover:bg-gray-100'
            }`}>
              <Icon className="w-5 h-5" />
            </div>
            <span className={`text-xs font-medium transition-colors ${
              isActive ? 'text-indigo-900' : 'text-gray-500'
            }`}>
              {item.label}
            </span>
            {isActive && (
              <motion.div 
                layoutId="active-rail"
                className="absolute -right-[1px] top-1/2 -translate-y-1/2 w-1 h-8 bg-indigo-600 rounded-l-full"
              />
            )}
          </button>
        );
      })}
    </div>
  );
};

export const BottomBar = ({ activeTab, onTabChange }: { activeTab: string, onTabChange: (id: string) => void }) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-2 pb-6 z-40 flex justify-between items-center shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className="flex flex-col items-center gap-1 p-2 relative"
          >
            <div className={`w-16 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
              isActive ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'
            }`}>
              <Icon className={`w-5 h-5 ${isActive ? 'fill-current' : ''}`} />
            </div>
            <span className={`text-xs font-medium ${
              isActive ? 'text-indigo-900' : 'text-gray-500'
            }`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};

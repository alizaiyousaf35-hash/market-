import { 
  Gamepad2, 
  Briefcase, 
  Music, 
  Video, 
  Map, 
  Heart, 
  Camera, 
  Zap,
  Shield,
  Cloud,
  Mail,
  Calendar
} from 'lucide-react';

export interface AppData {
  id: string;
  title: string;
  developer: string;
  rating: number;
  downloads: string;
  category: string;
  description: string;
  icon: string;
  screenshots: string[];
  tags: string[];
  isFeatured?: boolean;
  accentColor: string;
}

export const CATEGORIES = [
  { id: 'all', label: 'For You', icon: Heart },
  { id: 'games', label: 'Games', icon: Gamepad2 },
  { id: 'productivity', label: 'Productivity', icon: Briefcase },
  { id: 'social', label: 'Social', icon: Mail },
  { id: 'media', label: 'Media', icon: Video },
];

export const MOCK_APPS: AppData[] = [
  {
    id: '1',
    title: 'Zenith Sky',
    developer: 'Atmosphere Labs',
    rating: 4.8,
    downloads: '10M+',
    category: 'games',
    description: 'Explore a vast, open-world universe in this breathtaking aerial adventure. Soar through clouds, discover floating islands, and uncover the secrets of the ancients.',
    icon: 'https://picsum.photos/seed/zenith/200/200',
    screenshots: [
      'https://picsum.photos/seed/zenith1/600/400',
      'https://picsum.photos/seed/zenith2/600/400',
      'https://picsum.photos/seed/zenith3/600/400',
    ],
    tags: ['Adventure', 'Indie', 'Relaxing'],
    accentColor: 'bg-indigo-100 text-indigo-900',
  },
  {
    id: '2',
    title: 'Focus Flow',
    developer: 'Mindful Tech',
    rating: 4.9,
    downloads: '5M+',
    category: 'productivity',
    description: 'Boost your productivity with a timer designed for deep work. Features ambient soundscapes, task tracking, and detailed analytics.',
    icon: 'https://picsum.photos/seed/focus/200/200',
    screenshots: [
      'https://picsum.photos/seed/focus1/600/400',
      'https://picsum.photos/seed/focus2/600/400',
    ],
    tags: ['Productivity', 'Tools', 'Editor\'s Choice'],
    accentColor: 'bg-emerald-100 text-emerald-900',
  },
  {
    id: '3',
    title: 'Pixel Painter',
    developer: 'Creative Studio',
    rating: 4.5,
    downloads: '1M+',
    category: 'media',
    description: 'Create stunning pixel art on the go. Intuitive tools, layer support, and animation features make this the ultimate pocket studio.',
    icon: 'https://picsum.photos/seed/pixel/200/200',
    screenshots: [
      'https://picsum.photos/seed/pixel1/600/400',
      'https://picsum.photos/seed/pixel2/600/400',
    ],
    tags: ['Art', 'Design', 'Creative'],
    accentColor: 'bg-rose-100 text-rose-900',
  },
  {
    id: '4',
    title: 'Echo Social',
    developer: 'Connect Corp',
    rating: 4.2,
    downloads: '50M+',
    category: 'social',
    description: 'Connect with friends in a new way. Voice-first social networking that feels natural and spontaneous.',
    icon: 'https://picsum.photos/seed/echo/200/200',
    screenshots: [
      'https://picsum.photos/seed/echo1/600/400',
      'https://picsum.photos/seed/echo2/600/400',
    ],
    tags: ['Social', 'Communication'],
    accentColor: 'bg-blue-100 text-blue-900',
  },
  {
    id: '5',
    title: 'Cyber Drift',
    developer: 'Neon Games',
    rating: 4.7,
    downloads: '2M+',
    category: 'games',
    description: 'High-octane racing in a neon-soaked cyberpunk city. Customize your ride and dominate the streets.',
    icon: 'https://picsum.photos/seed/drift/200/200',
    screenshots: [
      'https://picsum.photos/seed/drift1/600/400',
      'https://picsum.photos/seed/drift2/600/400',
    ],
    tags: ['Racing', 'Action', 'Multiplayer'],
    accentColor: 'bg-fuchsia-100 text-fuchsia-900',
  },
  {
    id: '6',
    title: 'Nova Maps',
    developer: 'Terra Inc',
    rating: 4.6,
    downloads: '100K+',
    category: 'productivity',
    description: 'Offline maps for the modern explorer. Detailed topographic data, trail guides, and community waypoints.',
    icon: 'https://picsum.photos/seed/nova/200/200',
    screenshots: [
      'https://picsum.photos/seed/nova1/600/400',
    ],
    tags: ['Travel', 'Navigation', 'Offline'],
    accentColor: 'bg-amber-100 text-amber-900',
  },
  {
    id: '7',
    title: 'Lumina',
    developer: 'Lightworks',
    rating: 4.9,
    downloads: '500K+',
    category: 'media',
    description: 'Professional photo editing with AI-powered enhancements. Relight your photos in post-processing.',
    icon: 'https://picsum.photos/seed/lumina/200/200',
    screenshots: [
      'https://picsum.photos/seed/lumina1/600/400',
    ],
    tags: ['Photography', 'AI', 'Tools'],
    accentColor: 'bg-purple-100 text-purple-900',
  },
  {
    id: '8',
    title: 'Vault Secure',
    developer: 'Shield Systems',
    rating: 4.8,
    downloads: '1M+',
    category: 'productivity',
    description: 'Keep your passwords and digital identity safe. Military-grade encryption with a beautiful, easy-to-use interface.',
    icon: 'https://picsum.photos/seed/vault/200/200',
    screenshots: [
      'https://picsum.photos/seed/vault1/600/400',
    ],
    tags: ['Security', 'Utility'],
    accentColor: 'bg-slate-100 text-slate-900',
  },
  {
    id: '9',
    title: 'KineMaster Pro',
    developer: 'KineMaster Corporation',
    rating: 4.9,
    downloads: '100M+',
    category: 'media',
    description: 'Professional video editing made easy. Features multi-layer video, blending modes, voiceovers, chroma key, speed control, transitions, subtitles, special effects, and so much more! Find out why creators love KineMaster for YouTube, TikTok, and Instagram.',
    icon: 'https://picsum.photos/seed/kinemaster/200/200',
    screenshots: [
      'https://picsum.photos/seed/video_editor_ui/800/450', // Export UI
      'https://picsum.photos/seed/4k_resolution/800/450',   // Quality
      'https://picsum.photos/seed/celebration/450/800',     // Occasion (Portrait)
      'https://picsum.photos/seed/typography/450/800',      // Text (Portrait)
      'https://picsum.photos/seed/color_grading/800/450',   // Cinematic
      'https://picsum.photos/seed/stickers_art/800/450',    // Stickers
      'https://picsum.photos/seed/audio_mixer/800/450',     // Audio
      'https://picsum.photos/seed/chroma_key/800/450',      // Chroma Key
      'https://picsum.photos/seed/visual_effects/450/800',  // Effects (Portrait)
    ],
    tags: ['Video Editor', 'Vlog', 'Effects', '4K'],
    isFeatured: true,
    accentColor: 'bg-orange-100 text-orange-900',
  }
];

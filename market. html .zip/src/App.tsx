import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { MoreVertical } from 'lucide-react';
import { TopBar, NavigationRail, BottomBar } from './components/Navigation';
import { AppCard, AppDetailView } from './components/AppComponents';
import { MOCK_APPS, CATEGORIES, AppData } from './data';

export default function App() {
  const [selectedApp, setSelectedApp] = useState<AppData | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeNav, setActiveNav] = useState('games');
  const [searchQuery, setSearchQuery] = useState('');

  const featuredApp = MOCK_APPS.find(app => app.isFeatured) || MOCK_APPS[0];
  const otherApps = MOCK_APPS.filter(app => app.id !== featuredApp.id);

  // Filter logic
  const filteredApps = otherApps.filter(app => {
    const matchesCategory = activeCategory === 'all' || app.category === activeCategory;
    const matchesSearch = app.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          app.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const topChartApps = [...MOCK_APPS].sort((a, b) => b.rating - a.rating).slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-gray-900 selection:bg-indigo-100 selection:text-indigo-900">
      <TopBar onSearch={setSearchQuery} />
      
      <div className="flex max-w-7xl mx-auto">
        <NavigationRail activeTab={activeNav} onTabChange={setActiveNav} />
        
        <main className="flex-1 p-4 md:p-8 pb-24 overflow-x-hidden">
          {/* Categories */}
          <div className="flex gap-3 overflow-x-auto pb-8 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0 sticky top-[72px] z-30 bg-slate-50/95 backdrop-blur-sm py-4">
            {CATEGORIES.map(cat => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full whitespace-nowrap transition-all duration-300 border ${
                    isActive 
                      ? 'bg-gray-900 text-white border-gray-900 shadow-lg shadow-gray-200 scale-105' 
                      : 'bg-white text-gray-600 border-transparent hover:bg-gray-100 hover:border-gray-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium text-sm">{cat.label}</span>
                </button>
              );
            })}
          </div>

          <div className="grid lg:grid-cols-[1fr,320px] gap-8">
            <div className="space-y-10">
              {/* Featured Section - Only show if no search query and 'all' category */}
              {activeCategory === 'all' && !searchQuery && (
                <section>
                  <h2 className="text-2xl font-bold mb-6 px-1 flex items-center gap-2">
                    Featured 
                    <span className="text-xs font-normal text-gray-500 bg-gray-200 px-2 py-1 rounded-md">Today</span>
                  </h2>
                  <AppCard 
                    app={featuredApp} 
                    onClick={setSelectedApp} 
                    variant="featured" 
                  />
                </section>
              )}

              {/* App Grid */}
              <section>
                <div className="flex items-center justify-between mb-6 px-1">
                  <h2 className="text-2xl font-bold">
                    {searchQuery ? `Search results for "${searchQuery}"` : (activeCategory === 'all' ? 'Recommended for you' : CATEGORIES.find(c => c.id === activeCategory)?.label)}
                  </h2>
                  {!searchQuery && <button className="text-indigo-600 font-medium text-sm hover:underline bg-indigo-50 px-3 py-1 rounded-full">See all</button>}
                </div>
                
                {filteredApps.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {filteredApps.map(app => (
                      <AppCard 
                        key={app.id} 
                        app={app} 
                        onClick={setSelectedApp} 
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 text-gray-500">
                    No apps found matching your criteria.
                  </div>
                )}
              </section>
            </div>

            {/* Sidebar / Top Charts */}
            <aside className="space-y-8 hidden lg:block">
              <section className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">Top Charts</h2>
                  <button className="text-gray-400 hover:text-gray-600">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-2">
                  {topChartApps.map((app, index) => (
                    <AppCard 
                      key={app.id} 
                      app={app} 
                      onClick={setSelectedApp} 
                      variant="chart"
                      rank={index + 1}
                    />
                  ))}
                </div>
                <button className="w-full mt-6 py-3 text-center text-sm font-bold text-gray-600 hover:bg-gray-50 rounded-xl transition-colors">
                  View full charts
                </button>
              </section>

              <section className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-[32px] p-8 text-white shadow-xl shadow-indigo-200">
                <h3 className="text-2xl font-bold mb-2">Premium Pass</h3>
                <p className="text-indigo-100 mb-6">Get access to hundreds of premium games and apps without ads.</p>
                <button className="w-full bg-white text-indigo-600 py-3 rounded-full font-bold shadow-lg hover:bg-indigo-50 transition-colors">
                  Try it free
                </button>
              </section>
            </aside>
          </div>
        </main>
      </div>

      <BottomBar activeTab={activeNav} onTabChange={setActiveNav} />

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedApp && (
          <AppDetailView 
            app={selectedApp} 
            onClose={() => setSelectedApp(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
